first open the terminal.

Then give mvn clean command

Then give mvn compile command

Then give mvn package command and you will see that if the code is correct it will pass the test cases.

Then do cd target.

There type java --module-path "C:\Users\leech\Downloads\openjfx-21.0.1_windows-x64_bin-sdk\javafx-sdk-21.0.1\lib" --add-modules javafx.controls,javafx.fxml -jar .\demo1-1.0-SNAPSHOT.jar
just replace the "C:\Users\leech\Downloads\openjfx-21.0.1_windows-x64_bin-sdk\javafx-sdk-21.0.1\lib" with you java sdk lib path and the program will run

first the program will ask you to register or login. And even i you close the game the user is still stored and the next
time you open the game you can simply login

after login is successfully completed you can play the game by clicking on the play button, the cherry icon will show
you how many cherries have you collected and the leader board option will tell you the top 3 scorers.

Once you press the play button the game starts, mouse click for a particular time incrase the length of the rod and when you
will release it , it will rotate and fall down , and if lands on the width of the destination tower the player moves forward else
the player falls. Also while moving the player can collect cherries by pressing space bar at the exact time where the cherry
is located.

This screen has a pause button where you can save the state of the game.Then you can see the resume button on the first screen.

When you will fall a third screen will appear which will have the play again button, home button and the see leader board button clicking on it.
Clicking on the play again button the game again starts, clicking on the home button takes you to the first screen and clicking on the
leaderboard button will show you the leaderboard.

Thank you
kartikeya 2022241
Aahan Piplani 2022001

github repo link: https://github.com/Kartikeya2022241/AP_PROJECT



