package com.example.demo1;

public class Main_menu {
    public static void main(String[] argv) {
        LoadGame obj=LoadGame.get_load_game();
        //String [] arr={"kartikeya","i am"};
        //HelloApplication.main(arr);

    }
}
