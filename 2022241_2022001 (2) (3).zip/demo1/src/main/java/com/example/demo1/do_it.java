package com.example.demo1;

import javafx.stage.Stage;

import static javafx.application.Application.launch;

public interface do_it {
    public void start(Stage stage);

    public static void l() {
        launch();
    }
}
