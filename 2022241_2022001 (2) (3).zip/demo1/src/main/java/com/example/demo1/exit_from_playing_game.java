package com.example.demo1;

public class exit_from_playing_game {
}
