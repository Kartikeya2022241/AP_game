package com.example.demo1;

public class how_to_play {
}
