package com.example.demo1;

public abstract class something {
    public abstract void do_work();
}
